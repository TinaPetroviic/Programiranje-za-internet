<?php

session_start();

require 'zaglavlje.php';

?>
<!-- Start Contact Section -->


        <div class="container">
            <div class="row">
                <div class="text-center">
                    <h1 style="color:white;">Kontaktirajte nas</h1>
                    
                </div>
            </div>
            <div class="row">

                <div class="col-md-4" >
                    <div class="footer-contact-info">
                        <h4>Kontakt informacije</h4>
                        <ul>
                            <li><strong>E-mail :</strong> ticketbuy@mail.com</li>
                            <li><strong>Phone :</strong> +8801-6778776</li>
                            <li><strong>Mobile :</strong> +8801-45565378</li>
                            <li><strong>Web :</strong>www.ticketbuy.com</li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="footer-social text-center">
                        <ul>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="footer-contact-info">
                        <h4>Radno vrijeme</h4>
                        <ul>
                            <li><strong>Pon-Sub :</strong> 0 - 24 h</li>
                            <li><strong>Nedjelja :</strong> Zatvoreno</li>
							<li><br></li>
							<li><br></li>
                        </ul>
                    </div>
                </div>

            </div><!--/.row -->
            <br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
        </div>

 
<!-- End Cntact Section -->

<?php

require 'modali.php';
require 'podnozje.php';

?>